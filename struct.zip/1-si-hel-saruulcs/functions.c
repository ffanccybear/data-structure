#include "myinclude.h"

void read(int A[], int n)
{
        int i;
        for (i = 0; i < n; i++)
                scanf("%d", &A[i]);
}

void print(int A[], int n)
{
        int i;
        for (i = 0; i < n; i++)
                printf("%d ", A[i]);
        printf("\n");
}

int max(int A[], int n)
{
        int maxim = A[0] ;
        for(int i=0;i<n;i++){
                if (A[i] > maxim){
                        maxim = A[i] ;
                }
        }
        return maxim ;
}

int min(int A[], int n)
{
        // Энд функцыг хэрэгжүүл   
        int minim = A[0] ;
        for(int i=0;i<n;i++){
                if (A[i] < minim){
                        minim = A[i] ;
                }
        }
        return minim ;     
}

void copy(int A[], int n, int B[])
{
        // Энд функцыг хэрэгжүүл
        for(int i=0; i < n; i++){
                B[i] = A[i] ;
        }       
}

int find(int A[], int n, int x)
{
        // Энд функцыг хэрэгжүүл
        for(int i=0; i < n; i++){
                if (A[i] == x){
                        return i ;
                }
        }
        return -1 ;        
}

int make_set(int A[], int n, int B[])
{
        int sz = 0, idx = 0;
        // Энд функцыг хэрэгжүүл
        for(int i=0; i < n; i++){

                int bo = 1;
                for (int j = 0; j < i; j++){
                        if (A[i] == A[j]){
                                bo = 0;
                                break;
                        }
                }

                if (bo){
                        B[idx++] = A[i];
                        sz++;
                }
        }
        return sz ;   
}

int union_set(int A[], int n, int B[], int m)
{
        // Энд функцыг хэрэгжүүл
        copy(A, n, B + m);
        return make_set(B, n + m, A);        
}

int intersection_set(int A[], int n, int B[], int m, int C[])
{
        int idx = 0;
        // Энд функцыг хэрэгжүүл
        for(int i=0; i < n; i++){
                int bo = 0;

                for(int j = 0; j < m; j++){
                        if (A[i] == B[j]){
                                bo = 1;
                                break;
                        }
                }

                if (bo)
                {
                        C[idx++] = A[i];
                }
        }

        return idx;
}

