#include "DS.h"
/*
  Графыг эхлүүлэх функц: `g` графын хөршүүдийг хадгалах жагсаалтан хүснэгтийг эхлүүлэх функц.
  Санах ойг бэлдэж, жагсаалтын `head`, `tail` утгуудад `NULL` онооно.
 */
void gr_init_graph(Graph *g, int n)
{
	int i;
	g->adj = (List *) malloc(sizeof(List) * (n + 1));
	g->n = n;
	for (i = 0; i <= n; i++) {
		g->adj[i].head = g->adj[i].tail = NULL;
		g->adj[i].len = 0;
	}
}


int cnt = 1 ;
/* Tuhain oroi deer temdeglegee hiih tul v buyu oroi, visited husnegtiig heregelsen*/

void DFS(Graph *g, int v, int visited[]){
	
	/* v oroitoi holbootoi buh elementuudiin medeellig hadgalah adj list  */
    List adj = g->adj[v] ;
	/* adjacent husnegtiin odoo baigaa tuluviig tur hadgalah
	tmp jagsaaltiig hereglesen */
	List *tmp = &adj;
	/* ochson node oo ochson gej temdeglene */
	visited[v] = 1 ;
	/* 	Husnegtiin tolgoi haygiig NULL boltol shalgana */
	while (tmp->head != NULL){
		/* Tiim bolohoor end husnegtiin medeellig uurchluhgui bol 
		 loop infinite*/
		 int vert = tmp->head->x ;
		 l_pop_front(tmp) ; // End urdaas ni ustgaad, tmp husnegt update hiigdene
		/* Hervee tuhain node deer ochoogui bol */
		if (visited[vert] == 0){
			cnt++ ; //cnt iig 1 eer nemegduulne. Uchir ni DFS iig heden udaa duudna
			// ter too ni heden shirheg component baina ve gedgiig ilerhiilne
			DFS(g, vert, visited) ;
		}
	}
}


/*
  Гүний нэвтрэлтийн функц: `g` граф дээр гүний нэвтрэлт хийн холбоост бүрдлүүдийн талаарх
  даалгаварт заагдсан мэдээллийг хэвлэнэ.
 */
void gr_connected_components(Graph *g, int *cc)
{
	/* Энд функцийг хэрэгжүүл */
	int v ;
	/* g graphiin oroin too	*/
	int V = g->n ;
	/* tuhain oroi deer ochson esehiig mark hiij temdegleh visited array */
	int visited[V+1] ;

	int t = 0 ; 

	for(v = 1; v < V+1; v++){
		visited[v] = 0 ; 
	}
	for(v = 1; v < V+1; v++){
		/* Hervee tuhain oroi deer umnu ni ochij baigaagui bol
		ter node ruu ochood, tendeese ahiad daraagiin adjacent node ruu ochih ystoi */
		if (visited[v] == 0){
			/* tuhain oroi deer ochood ochson gej temdegleh ystoi
			uuniig shalgahiin tuld helper function nemj bichsen 
			DFS Funkts*/

			// chekcer funktsiig end bichne ;

			DFS(g, v, visited) ;
			t++ ;
			/*cc husnegtiin ehnii element l husnegted oruulsan elementiin too buyu
			niit heden burdel heseg baigaa talaarhi medeellig hadgalj baigaa 
			harin busad tohioldold component tus buriin oroin toog hadgalna*/
 
			cc[t] = cnt;

		}
		cnt  = 1 ;
	} 
	cc[0] = t ;
}

/*
  Ирмэг нэмэх функц: `g` графын ирмэгүүдийг хадгалах `adj` жагсаалтан хүснэгтэд ирмэг нэмнэ.
  Уг граф нь чиглэлгүй граф тул `x`-с `y`, `y`-с `x` гэсэн хоёр ирмэгийг оруулна.
 */
void gr_add_edge(Graph *g, int x, int y)
{
	/* Энд функцийг хэрэгжүүл */
	/* Graph butets ni uuruu adj listee aguuldag*/
	l_push_back(&g->adj[x] ,y) ;
	l_push_back(&g->adj[y], x) ;
	/* chiglelgui graph bolohoor
	x ees y ruu, y ees x ruu gesen 
	2 zamiig oruulj ugnu */	
}
