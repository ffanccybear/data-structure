#ifndef __MYQUICKSORT_H
#define __MYQUICKSORT_H

#include <stdlib.h>
#include <time.h>

void single_pivot_qsort(int [], int, int);
void dual_pivot_qsort(int [], int, int);

#endif
