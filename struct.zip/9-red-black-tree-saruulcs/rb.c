#include "DS.h"

/*
  Хоёр оюутны мэдээллийн хооронд нь харьцуулах функц
*/
int less(const Student *a, const Student *b)
{
	if (strcmp(a->id, b->id) < 0){
                return 1 ;
        }
        else {
                return 0; 
        }
}

struct Elm *root = NULL ;

int color(Elm *root){
        if (root == NULL){
                return 0 ;
        }
        return root->color ;
}

/*yal
  `ptree`-ийн зааж байгаа модонд `x` утгыг оруулна.
  Мод хоосон байсан бол `ptree->root` хаяг өөрчлөгдөж шинээр орсон оройг заана.
  Хэрэв мод тэнцвэрээ алдсан бол тохирох тэнцвэржүүлэх үйлдлүүдийг хийнэ.
 */
// Left rotation method 
Elm *leftrotate(Elm *node){
        Elm *right = node->R ;
        node->R = right->L ;
        if (node->R){
                node->R->parent = node ; 
        }
        right->parent = node->parent ;
        if (!node->R){
                root = right ;
        }
        else if (node == node->parent->L){
                node->parent->L = right ;
        }
        else {
                node->parent->R = right ;
        }
        right->L = node ;
        node->parent = right ;
}
// Right rotation method 
Elm *rightrotate(Elm *node){
        Elm *left = node->L ; 
        node->L = left->R ;
        if (node->L){
                node->L->parent = node; 
        }
        left->parent = node->parent ;
        if (!node->parent){
                root = left ;
        }
        else if (node == node->parent->L){
                node->parent->L = left ;
        }
        else {
                node->parent->L = left ;
        }
        left->R = node ;
        node->parent = left ;
}

void fixup(Elm* root, Elm *pt)
{
    Elm *parent_pt = NULL;
    Elm *grand_parent_pt = NULL;
 
    while ((pt != root) && (pt->color != 0)
           && (pt->parent->color == 1))
    {
        parent_pt = pt->parent;
        grand_parent_pt = pt->parent->parent;
 
        /*  Case : A
             Parent of pt is left child
             of Grand-parent of
           pt */
        if (parent_pt == grand_parent_pt->L)
        {
 
            Elm* uncle_pt = grand_parent_pt->R;
 
            /* Case : 1
                The uncle of pt is also red
                Only Recoloring required */
            if (uncle_pt != NULL && uncle_pt->color == 1)
            {
                grand_parent_pt->color = 1;
                parent_pt->color = 0;
                uncle_pt->color = 0;
                pt = grand_parent_pt;
            }
 
            else {
 
                /* Case : 2
                     pt is right child of its parent
                     Left-rotation required */
                if (pt == parent_pt->R) {
                    leftrotate(parent_pt);
                    pt = parent_pt;
                    parent_pt = pt->parent;
                }
 
                /* Case : 3
                     pt is left child of its parent
                     Right-rotation required */
                rightrotate(grand_parent_pt);
                int t = parent_pt->color;
                parent_pt->color = grand_parent_pt->color;
                grand_parent_pt->color = t;
                pt = parent_pt;
            }
        }
 
        /* Case : B
             Parent of pt is right
             child of Grand-parent of
           pt */
        else {
            Elm* uncle_pt = grand_parent_pt->L;
 
            /*  Case : 1
                The uncle of pt is also red
                Only Recoloring required */
            if ((uncle_pt != NULL) && (uncle_pt->color == 1))
            {
                grand_parent_pt->color = 1;
                parent_pt->color = 0;
                uncle_pt->color = 0;
                pt = grand_parent_pt;
            }
            else {
                /* Case : 2
                   pt is left child of its parent
                   Right-rotation required */
                if (pt == parent_pt->L) {
                    rightrotate(parent_pt);
                    pt = parent_pt;
                    parent_pt = pt->parent;
                }
 
                /* Case : 3
                     pt is right child of its parent
                     Left-rotation required */
                leftrotate(grand_parent_pt);
                int t = parent_pt->color;
                parent_pt->color = grand_parent_pt->color;
                grand_parent_pt->color = t;
                pt = parent_pt;
            }
        }
    }
 
    root->color = 0;
}

Elm *insert(Elm *tree, const Student *st){
        if (tree == NULL){
                Elm *elm = malloc(sizeof(Elm)) ;
                elm->x = *st ;
                elm->L = elm->R = NULL ;
                elm->color = 1 ;
                /* hervee root hooson bol shineer oroh utgiinhaa
                strutciin haygiig ni ugnu */

                tree = elm ;
                return elm ;
        }

        int result = strcmp(tree->x.id, st->id) ;

        if (result == -1){
                tree->R = insert(tree->R, st) ;
        }

        else if (result == 1) {
                tree->L = insert(tree->L, st) ;

        }
        else {
                tree->x = *st ;
        }

        if (color(tree->R) && !color(tree->L)){
                tree = leftrotate(tree) ;
        }
        if (color(tree->L) && color(tree->L->L)){
                tree = rightrotate(tree) ;
        }
        if (color(tree->L) && color(tree->R)){
                if (color(tree) == 0){
                        if(color(tree->R ==1) && color(tree->L) == 1){
                                tree->color = 1 ; // RED 
                                tree->L->color = 0 ; // BLACK 
                                tree->L->color = 0 ; //BLACK
                        }
                }
                if (color(tree) == 1){
                        if (color(tree->R == 0) && color(tree->R) == 0){
                                tree->color = 0 ;
                                tree->L->color = 1 ;
                                tree->R->color = 1 ;
                        }
                }
        } 
}


void rb_put(RBT *ptree, const Student *px)
{
        // Функцийг хэрэгжүүлнэ үү
        // createvoid new node ;
        // Elm *ptr = (Elm *) malloc(sizeof(Elm)) ;
        // ptr->x = *px ;
        // ptr->L = ptr->R = ptr->parent = NULL ;
        // // if root is null make ptr as root ;
        // if (ptree->root == NULL){
        //         ptr->color = 0 ;
        //         ptree->root = ptr ;
        // }
        // else {
        //         Elm *n = NULL ;
        //         Elm *m = ptree->root ;
        //         while(m != NULL){
        //                 n = m ;
        //                 // printf("PISDAAAAAAAAAAAAAAA");
        //                 printf("%s vs %s", ptr->x.name, m->x.name) ;
        //                 if ((less(&ptr->x, &m->x)) < 0){
        //                         // printf("PISDAAAAAAAAAAAAAAA");
        //                         m = m->L ;
        //                 }
        //                 else {
        //                         // printf("PISDAAAAAAAAAAAAAAA");
        //                         n = n->R ;
        //                 }
        //         } 
        //         ptr->parent = n ;
        //         if (!less(&ptr->x, &n->x)){
        //                 n->R = ptr ;
        //         }
        //         else {
        //                 n->L = ptr ;
        //         }
        //         ptr->color = 1 ;
        //         fixup(ptree->root, ptr) ;
        // }
        ptree->root = insert(ptree->root, px) ;

}       


/*
  `ptree`-ийн зааж байгаа модноос `x` утгыг хайн олдсон оройн `Elm*` хаягийг буцаана.
  Олдохгүй бол `NULL` хаягийг буцаана.
  Мод дандаа ялгаатай элементүүд хадгална гэж үзэж болно.
 */

int compareChar(const char id1[], const char id2[]){
    return strcmp(id1, id2) ;
}

Elm *rb_get(const RBT *ptree, const char id[])
{
        // Функцийг хэрэгжүүлнэ үү
        Elm *ptr ;
        ptr = ptree->root ;
        while (ptr != NULL){
                int result ;
                result = compareChar(ptr->x.id, id) ;
                if (result == 0){
                        return ptr ;
                }
                ptr = result < 0 ? ptr->L : ptr->R ;
        }
        return NULL ; 
}

/*
  Устгах функц: ТМноос `x` утгыг хайж олоод устгана.
  Олдохгүй бол юу ч хийхгүй.
  Хэрэв мод тэнцвэрээ алдсан бол тохирох тэнцвэржүүлэх үйлдлүүдийг хийнэ.
 */
void rb_del(RBT *ptree, const char id[])
{
        // Функцийг хэрэгжүүлнэ үү


}

void print(Elm *p)
{
	if (p)
		printf("%s %s %d %.1f\n", p->x.name, p->x.id, p->x.age, p->x.gpa);
	else
		printf("None\n");
}
