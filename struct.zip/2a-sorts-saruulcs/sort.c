#include "sort.h"
void read(int a[], int n)
{
	int i;
	for (i = 0; i < n; i++)
            scanf("%d", &a[i]);
}

void print(int a[], int n)
{
	int i;
	for (i = 0; i < n; i++)
		printf("%d ", a[i]);
	printf("\n");
}

void insertion_sort(int a[], int n)
{
	/***************************************************
	 * Даалгавар: Энэ хэсэгт өөрийн insertion sort-ийг
	 * хийх кодыг бичнэ.
	 * a     нь эрэмбэлэх хүснэгт
	 * n     нь хүснэгтэд байгаа утгуудын тоо
	 ***************************************************/
	for(int i=1; i < n ; i++){ 
		// 99 1 1 4 5 99
		// 0  1 2 3 4 5		
		int currPos = a[i] ;				
		int prevPos = i - 1 ;	
		while(currPos < a[prevPos] && prevPos >= 0){
			a[prevPos + 1] = a[prevPos] ;
			prevPos-- ;
		}
		a[prevPos + 1] = currPos ;
	}
}		

void selection_sort(int a[], int n)
{
	/***************************************************
	 * Даалгавар: Энэ хэсэгт өөрийн selection sort-ийг
	 * хийх кодыг бичнэ.	
	 * a     нь эрэмбэлэх хүснэгт
	 * n     нь хүснэгтэд байгаа утгуудын тоо
	 ***************************************************/
    for (int i = 0; i < n; i++){
		int minim = i;
		for(int j=i+1; j<n; j++){
			if (a[j] < a[minim]){
				minim = j ;
			}
		}
		int tmp = a[minim] ;
		a[minim] = a[i] ;
		a[i] = tmp ;
	}

}

void bubble_sort(int a[], int n)
{
	/***************************************************
	 * Даалгавар: Энэ хэсэгт өөрийн bubble sort-ийг
	 * хийх кодыг бичнэ.
	 * a     нь эрэмбэлэх хүснэгт
	 * n     нь хүснэгтэд байгаа утгуудын тоо		
	 ***************************************************/
	for(int i=0; i < n; i++){
		// 4, 3, 5, 6, 2 ;
		// i = 2 ; 
		for(int j = 0; j < n - i - 1; j++){
			if (a[j] > a[j+1]){
				int tmp = a[j] ;
				a[j] = a[j+1] ;
				a[j+1] = tmp ;
			}
		}
	}
}
